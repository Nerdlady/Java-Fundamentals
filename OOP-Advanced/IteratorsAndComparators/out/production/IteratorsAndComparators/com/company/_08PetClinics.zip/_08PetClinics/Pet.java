package com.company._08PetClinics;

public interface Pet {
    String getName();
    String getKind();
    int getAge();
}
