package com.company._06MirrorImage.interfaces;

import com.company._06MirrorImage.events.WizardEvent;

public interface WizardListener {
    void handleReflectionEvent(WizardEvent event);
}
