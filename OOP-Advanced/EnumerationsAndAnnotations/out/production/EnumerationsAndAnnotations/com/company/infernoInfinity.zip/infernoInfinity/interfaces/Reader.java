package com.company.infernoInfinity.interfaces;

public interface Reader {
    String readLine();
}
