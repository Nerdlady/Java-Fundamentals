package com.company._02KingGambit.interfaces;

public interface Attackable {
    void respondToAttack();
}
