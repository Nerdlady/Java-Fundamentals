package com.company._07_1984.interfaces;

import java.io.IOException;

public interface Reader {
    String readLine() throws IOException;
}
