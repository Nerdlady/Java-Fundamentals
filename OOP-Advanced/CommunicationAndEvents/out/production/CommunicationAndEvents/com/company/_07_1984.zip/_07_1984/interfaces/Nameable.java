package com.company._07_1984.interfaces;

public interface Nameable {
    String getName();
}
