package com.company._04WorkForce.interfaces;

public interface Employee {
    String getName();
    int getWorkHoursPerWeek();
}
