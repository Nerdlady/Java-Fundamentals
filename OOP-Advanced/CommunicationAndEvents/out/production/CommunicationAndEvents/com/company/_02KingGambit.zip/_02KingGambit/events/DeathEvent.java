package com.company._02KingGambit.events;

import java.util.EventObject;

public class DeathEvent extends EventObject {

    public DeathEvent(Object source) {
        super(source);
    }
}
