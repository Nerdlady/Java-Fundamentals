package com.company.P03_DependencyInversionSkeleton;

import com.company.P03_DependencyInversionSkeleton.interfaces.CalculatorStrategy;
import com.company.P03_DependencyInversionSkeleton.strategies.AdditionStrategy;
import com.company.P03_DependencyInversionSkeleton.strategies.DividingStrategy;
import com.company.P03_DependencyInversionSkeleton.strategies.MultiplyingStrategy;
import com.company.P03_DependencyInversionSkeleton.strategies.SubtractionStrategy;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        PrimitiveCalculator calculator = new PrimitiveCalculator();
        while (true){
            String line = reader.readLine();
            if (line.equals("End")){
                break;
            }

            String[] params = line.split("\\s+");
            if (params[0].equals("mode")){
                switch (params[1]){
                    case "+":
                        CalculatorStrategy additionStrategy = new AdditionStrategy();
                        calculator.changeStrategy(additionStrategy);
                        break;
                    case  "-":
                        CalculatorStrategy subtractionStrategy = new SubtractionStrategy();
                        calculator.changeStrategy(subtractionStrategy);
                        break;
                    case "*" :
                        CalculatorStrategy multiplyingStrategu = new MultiplyingStrategy();
                        calculator.changeStrategy(multiplyingStrategu);
                        break;
                    case "/":
                        CalculatorStrategy dividingStrategy = new DividingStrategy();
                        calculator.changeStrategy(dividingStrategy);
                }
            } else {
                int firstNumber = Integer.parseInt(params[0]);
                int secondNumber = Integer.parseInt(params[1]);
                System.out.println(calculator.performCalculation(firstNumber,secondNumber));
            }
        }
    }
}
