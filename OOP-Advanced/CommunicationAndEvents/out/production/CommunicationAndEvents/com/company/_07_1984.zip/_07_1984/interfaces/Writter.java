package com.company._07_1984.interfaces;

public interface Writter {
    void writeLine(String message);

    void write(String message);
}
