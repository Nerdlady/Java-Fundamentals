package com.company.infernoInfinity.interfaces;

public interface Engine {
    void run();
}
