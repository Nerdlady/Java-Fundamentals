package com.company._07_1984.interfaces;

public interface ObservableCreator {
    Observable createObservable(String[] observableParameters);
}
