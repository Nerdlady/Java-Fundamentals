package com.company._06MirrorImage.interfaces;

import com.company._06MirrorImage.enums.SpellType;

public interface Spell {
    void cast();
    SpellType getSpellType();
}
