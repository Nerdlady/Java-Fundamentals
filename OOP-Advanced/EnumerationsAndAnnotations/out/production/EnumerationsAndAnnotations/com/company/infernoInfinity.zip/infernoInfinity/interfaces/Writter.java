package com.company.infernoInfinity.interfaces;

public interface Writter {
    void write(String mesage);
    void writeOnNewLine(String message);
}
