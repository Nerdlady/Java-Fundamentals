package com.company._07EqualityLogic;

public interface Person extends Comparable<Person> {
    String getName();
    int getAge();
}
