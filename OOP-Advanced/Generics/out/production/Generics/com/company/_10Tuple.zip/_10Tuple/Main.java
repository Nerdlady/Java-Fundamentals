package com.company._10Tuple;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        Tuple<String,String> stringStringTuple = new TupleImpl<>();
        Tuple<String,Integer> stringIntegerTuple = new TupleImpl<>();
        Tuple<Integer,Double> integerDoubleTuple = new TupleImpl<>();
        String[] personInfo = reader.readLine().split("\\s+");
        String[] beersInfo = reader.readLine().split("\\s+");
        String[] doubleInfo = reader.readLine().split("\\s+");
        stringStringTuple.put(personInfo[0] +" " +personInfo[1],personInfo[2]);
        stringIntegerTuple.put(beersInfo[0],Integer.parseInt(beersInfo[1]));
        integerDoubleTuple.put(Integer.parseInt(doubleInfo[0]),Double.parseDouble(doubleInfo[1]));
        System.out.printf("%s -> %s%n",stringStringTuple.getKey(),stringStringTuple.getValue());
        System.out.printf("%s -> %d%n",stringIntegerTuple.getKey(),stringIntegerTuple.getValue());
        System.out.println(integerDoubleTuple.getKey() + " -> " +integerDoubleTuple.getValue());
    }
}
