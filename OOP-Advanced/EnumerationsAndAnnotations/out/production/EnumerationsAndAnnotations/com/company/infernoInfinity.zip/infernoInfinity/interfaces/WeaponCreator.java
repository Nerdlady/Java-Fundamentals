package com.company.infernoInfinity.interfaces;

public interface WeaponCreator {
    Weapon createWeapon(String type,String name);
}
