package com.company.P03_DependencyInversionSkeleton.interfaces;

public interface CalculatorStrategy {
    int calculate(int firstOperand, int secondOperand);
}
