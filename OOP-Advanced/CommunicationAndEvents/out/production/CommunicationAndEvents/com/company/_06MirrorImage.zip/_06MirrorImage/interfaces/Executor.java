package com.company._06MirrorImage.interfaces;

public interface Executor {
    void execute(String[] tokens);
}
