package com.company._06StrategyPattern;

public interface Person {
    String getName();

    int getAge();
}
