package com.company._06MirrorImage.enums;

public enum SpellType {
    REFLECTION,
    FIREBALL
}
