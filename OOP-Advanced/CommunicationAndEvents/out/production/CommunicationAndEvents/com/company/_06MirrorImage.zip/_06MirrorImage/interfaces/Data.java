package com.company._06MirrorImage.interfaces;

public interface Data {
    Wizard getWizard(int id);
    void addWizard(Wizard wizard);
    void removeWizard(Wizard wizard);
}
