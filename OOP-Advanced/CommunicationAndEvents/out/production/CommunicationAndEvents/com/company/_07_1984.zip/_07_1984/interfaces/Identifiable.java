package com.company._07_1984.interfaces;

public interface Identifiable {
    String getId();
}
