package com.company._03StackIterator;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

public class MyStackImpl implements MyStack {
    private List<Integer> myList;

    public MyStackImpl() {
        this.myList = new ArrayList<>();
    }

    @Override
    public void push(Integer... elements) {

            this.myList.addAll(Arrays.asList(elements));

    }

    @Override
    public void pop() {
        if (this.myList.size() <= 0){
            throw new IndexOutOfBoundsException("No elements");
        }
        this.myList.remove(this.myList.size() -1);
    }

    @Override
    public Iterator<Integer> iterator() {
        return new MyIterator(this.myList);
    }
}
