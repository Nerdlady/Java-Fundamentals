package com.company._08PetClinics;

public interface Room {
    int getId();
    Pet getPet();
    void setPet(Pet pet);
}
